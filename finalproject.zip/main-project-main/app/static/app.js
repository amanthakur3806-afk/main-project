/**
 * Multi-MCP Agent Platform — Frontend Controller
 *
 * Handles:
 *   - Agent list loading and live metadata display
 *   - Workflow execution via POST /agents/{id}/run
 *   - Rendering: Final Answer, Execution Trace, Sources, Prompt Audit, MCP Catalog
 *   - Knowledge base file upload
 *
 * No external dependencies. No emojis.
 */

"use strict";

// ---- Application State ---------------------------------------------------
let agentList = [];
let lastExecutionId = null;

// ---- Bootstrap -----------------------------------------------------------
(function init() {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();

function boot() {
  initTabs();
  loadAgents();
  loadMCPCatalog();
  initUploadForm();
  // Pre-fill query textarea with the first demo query
  const box = document.getElementById("queryBox");
  if (box && !box.value) {
    box.value =
      "Give me a complete summary of customer ABC including CRM profile, analytics metrics, recent activity, and internal documentation.";
  }
}

// ==========================================================================
// TAB SWITCHING
// ==========================================================================

function initTabs() {
  const buttons = document.querySelectorAll(".tab-btn");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      buttons.forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      const pane = document.getElementById(btn.dataset.tab);
      if (pane) pane.classList.add("active");
    });
  });
}

function activateTab(tabId) {
  const btn = document.querySelector(`[data-tab="${tabId}"]`);
  if (btn) btn.click();
}

// ==========================================================================
// AGENT LOADING
// ==========================================================================

async function loadAgents() {
  try {
    const res = await fetch("/agents");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    agentList = await res.json();

    const select = document.getElementById("agentSelect");
    select.innerHTML = "";
    agentList.forEach((agent, idx) => {
      const opt = document.createElement("option");
      opt.value = agent.agent_id;
      opt.textContent = `${agent.agent_name}  (${agent.agent_id})`;
      if (idx === 0) opt.selected = true;
      select.appendChild(opt);
    });

    select.addEventListener("change", () => onAgentChange(select.value));
    if (agentList.length > 0) onAgentChange(agentList[0].agent_id);
  } catch (err) {
    console.error("Failed to load agents:", err);
    const select = document.getElementById("agentSelect");
    select.innerHTML =
      '<option value="customer_research_agent">Customer Research Specialist  (customer_research_agent)</option>';
  }
}

function onAgentChange(agentId) {
  const agent = agentList.find((a) => a.agent_id === agentId);
  if (!agent) return;

  setText("agentModel", agent.model || "-");
  setText("agentTemp", agent.temperature !== undefined ? String(agent.temperature) : "-");

  const kb = agent.workflow_configuration?.knowledge_base || "None";
  setText("agentKB", kb);

  const toolsEl = document.getElementById("agentTools");
  if (toolsEl) {
    toolsEl.innerHTML = "";
    const tools = agent.allowed_tools || [];
    if (tools.length === 0) {
      toolsEl.innerHTML = '<span style="color:var(--text-muted);font-size:0.75rem;">No tools assigned</span>';
    } else {
      tools.forEach((t) => {
        const span = document.createElement("span");
        span.className = "tool-tag";
        span.textContent = t;
        toolsEl.appendChild(span);
      });
    }
  }
}

// Utility: set text content safely
function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

// ==========================================================================
// DEMO QUERY SETTER (called from HTML onclick)
// ==========================================================================

function setQuery(text) {
  const box = document.getElementById("queryBox");
  if (box) box.value = text;
}
window.setQuery = setQuery; // expose for inline onclick

// ==========================================================================
// RUN AGENT WORKFLOW
// ==========================================================================

async function runAgent() {
  const agentId =
    document.getElementById("agentSelect")?.value || "customer_research_agent";
  const query = (document.getElementById("queryBox")?.value || "").trim();
  const convId =
    (document.getElementById("convId")?.value || "").trim() || "conv_demo_01";

  if (!query) {
    alert("Please enter a query or select a sample query.");
    return;
  }

  setRunLoading(true);
  resetResults();

  try {
    const res = await fetch(`/agents/${agentId}/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, conversation_id: convId }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || `Agent run failed (HTTP ${res.status})`);
    }

    const data = await res.json();
    lastExecutionId = data.execution_id;

    renderAnswer(data);
    await fetchAndRenderTrace(data.execution_id);
    renderSources(data.sources || []);
    await fetchAndRenderPrompt(data.execution_id);

    // Auto-switch to the Final Answer tab
    activateTab("answerTab");
  } catch (err) {
    showError("Agent execution failed: " + err.message);
  } finally {
    setRunLoading(false);
  }
}
window.runAgent = runAgent;

function setRunLoading(on) {
  const btn = document.getElementById("runBtn");
  const spinner = document.getElementById("runSpinner");
  const label = document.getElementById("runLabel");
  if (!btn) return;
  btn.disabled = on;
  if (spinner) spinner.style.display = on ? "inline-block" : "none";
  if (label) label.textContent = on ? "Executing workflow..." : "Run Agent Workflow";
}

function resetResults() {
  // Answer
  const answerResult = document.getElementById("answerResult");
  const answerEmpty = document.getElementById("answerEmpty");
  if (answerResult) answerResult.style.display = "none";
  if (answerEmpty) answerEmpty.style.display = "flex";

  // Trace
  const traceList = document.getElementById("traceList");
  const traceEmpty = document.getElementById("traceEmpty");
  if (traceList) { traceList.style.display = "none"; traceList.innerHTML = ""; }
  if (traceEmpty) traceEmpty.style.display = "block";
  setText("traceCount", "0");

  // Sources
  const sourcesList = document.getElementById("sourcesList");
  const sourcesEmpty = document.getElementById("sourcesEmpty");
  if (sourcesList) { sourcesList.style.display = "none"; sourcesList.innerHTML = ""; }
  if (sourcesEmpty) sourcesEmpty.style.display = "block";
  setText("sourcesCount", "0");

  // Prompt
  setText("promptContent", "Fetching audit log...");
}

// ==========================================================================
// RENDER: FINAL ANSWER
// ==========================================================================

function renderAnswer(data) {
  const empty = document.getElementById("answerEmpty");
  const result = document.getElementById("answerResult");
  if (!result) return;

  if (empty) empty.style.display = "none";
  result.style.display = "block";

  setText("resultExecId", data.execution_id || "-");
  setText("resultDuration", `${data.duration_ms || 0}ms`);

  const statusEl = document.getElementById("resultStatus");
  if (statusEl) {
    const isOk = data.status === "completed";
    statusEl.textContent = isOk ? "Completed" : "Failed";
    statusEl.className = "tag " + (isOk ? "tag-green" : "tag-red");
  }

  const body = document.getElementById("answerBody");
  if (body) body.innerHTML = markdownToHtml(data.answer || "No answer returned.");
}

// ==========================================================================
// RENDER: EXECUTION TRACE
// ==========================================================================

async function fetchAndRenderTrace(executionId) {
  try {
    const res = await fetch(`/executions/${executionId}`);
    if (!res.ok) return;
    const data = await res.json();
    const steps = data.steps || [];

    setText("traceCount", String(steps.length));

    const empty = document.getElementById("traceEmpty");
    const list = document.getElementById("traceList");
    if (!list) return;

    if (steps.length === 0) {
      if (empty) empty.style.display = "block";
      return;
    }

    if (empty) empty.style.display = "none";
    list.style.display = "block";
    list.innerHTML = "";

    const wrapper = document.createElement("div");
    wrapper.className = "trace-list";

    steps.forEach((step) => {
      const isFailed = step.status === "failed";
      const card = document.createElement("div");
      card.className = "trace-step";

      // Header row (always visible, clickable to expand)
      const header = document.createElement("div");
      header.className = "trace-step-header";
      header.innerHTML = `
        <div class="step-num${isFailed ? " step-failed" : ""}">${step.step_number}</div>
        <div class="step-name">${escHtml(step.step_name)}</div>
        <div class="step-info-right">
          <span class="tag ${isFailed ? "tag-red" : "tag-green"}">${step.status}</span>
          <span>${step.duration_ms}ms</span>
          ${step.tool_name ? `<span class="tool-tag">${escHtml(step.tool_name)}</span>` : ""}
          <span style="color:var(--text-muted);">+</span>
        </div>
      `;

      // Body (expanded on click)
      const body = document.createElement("div");
      body.className = "trace-step-body";

      let bodyHtml = "";
      if (step.input_payload) {
        bodyHtml += `<div class="trace-payload-label">Input</div>
          <pre class="trace-payload">${escHtml(JSON.stringify(step.input_payload, null, 2))}</pre>`;
      }
      if (step.output_payload) {
        bodyHtml += `<div class="trace-payload-label">Output</div>
          <pre class="trace-payload">${escHtml(JSON.stringify(step.output_payload, null, 2))}</pre>`;
      }
      if (step.error_message) {
        bodyHtml += `<div class="trace-payload-label">Error</div>
          <pre class="trace-payload" style="color:#fca5a5;">${escHtml(step.error_message)}</pre>`;
      }
      if (!bodyHtml) bodyHtml = '<p style="font-size:0.75rem;color:var(--text-muted);">No payload recorded.</p>';
      body.innerHTML = bodyHtml;

      header.addEventListener("click", () => body.classList.toggle("open"));

      card.appendChild(header);
      card.appendChild(body);
      wrapper.appendChild(card);
    });

    list.appendChild(wrapper);
  } catch (err) {
    console.error("Failed to fetch trace:", err);
  }
}

// ==========================================================================
// RENDER: SOURCES / RAG
// ==========================================================================

function renderSources(sources) {
  const empty = document.getElementById("sourcesEmpty");
  const list = document.getElementById("sourcesList");
  setText("sourcesCount", String(sources.length));

  if (!list || sources.length === 0) {
    if (empty) empty.style.display = "block";
    return;
  }

  if (empty) empty.style.display = "none";
  list.style.display = "block";
  list.innerHTML = "";

  const wrapper = document.createElement("div");
  wrapper.className = "sources-list";

  sources.forEach((src) => {
    const card = document.createElement("div");
    card.className = "source-card";
    const pct = (src.similarity_score * 100).toFixed(1);
    card.innerHTML = `
      <div class="source-card-header">
        <span class="source-title">${escHtml(src.document_name)} &nbsp;&bull;&nbsp; Chunk #${src.chunk_index}</span>
        <span class="tag tag-blue">Similarity: ${pct}%</span>
      </div>
      <pre class="source-snippet">${escHtml(src.snippet || "")}</pre>
    `;
    wrapper.appendChild(card);
  });

  list.appendChild(wrapper);
}

// ==========================================================================
// RENDER: PROMPT AUDIT
// ==========================================================================

async function fetchAndRenderPrompt(executionId) {
  try {
    const res = await fetch(`/executions/${executionId}/prompt`);
    if (res.ok) {
      const text = await res.text();
      const el = document.getElementById("promptContent");
      if (el) el.textContent = text;
    } else {
      setText("promptContent", "Prompt log not yet available.");
    }
  } catch (err) {
    setText("promptContent", "Failed to load prompt log.");
    console.error("Prompt fetch error:", err);
  }
}

// ==========================================================================
// MCP CATALOG
// ==========================================================================

async function loadMCPCatalog() {
  try {
    // Servers
    const sRes = await fetch("/mcp/servers");
    if (!sRes.ok) return;
    const servers = await sRes.json();

    const serverGrid = document.getElementById("mcpServers");
    if (serverGrid) {
      serverGrid.innerHTML = "";
      servers.forEach((srv) => {
        const card = document.createElement("div");
        card.className = "mcp-server-card";
        card.innerHTML = `
          <div class="mcp-server-name">${escHtml(srv.server_name)}</div>
          <div class="mcp-server-detail">ID: <code>${escHtml(srv.server_id)}</code></div>
          <div class="mcp-server-detail">Transport: <span class="tag">${escHtml(srv.transport)}</span></div>
          <div class="mcp-server-detail">Status: <span class="tag tag-green">${escHtml(srv.status || "connected")}</span></div>
        `;
        serverGrid.appendChild(card);
      });
    }

    // Tools
    const tRes = await fetch("/mcp/tools");
    if (!tRes.ok) return;
    const tools = await tRes.json();

    const tableContainer = document.getElementById("mcpToolsTable");
    if (!tableContainer) return;

    let html = `<table><thead><tr>
      <th>Tool Name</th><th>Server</th><th class="td-desc">Description</th>
    </tr></thead><tbody>`;
    tools.forEach((t) => {
      html += `<tr>
        <td><code>${escHtml(t.tool_name)}</code></td>
        <td><span class="tag">${escHtml(t.server_id)}</span></td>
        <td class="td-desc">${escHtml(t.description)}</td>
      </tr>`;
    });
    html += "</tbody></table>";
    tableContainer.innerHTML = html;
  } catch (err) {
    console.error("Failed to load MCP catalog:", err);
  }
}

// ==========================================================================
// KNOWLEDGE UPLOAD
// ==========================================================================

function initUploadForm() {
  const form = document.getElementById("uploadForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const kbId = document.getElementById("uploadKB")?.value;
    const fileInput = document.getElementById("uploadFile");
    const statusEl = document.getElementById("uploadStatus");
    if (!fileInput?.files?.length) return;

    statusEl.textContent = "Uploading and chunking...";

    const formData = new FormData();
    formData.append("kb_id", kbId);
    formData.append("file", fileInput.files[0]);

    try {
      const res = await fetch("/knowledge/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (res.ok) {
        statusEl.textContent = `Ingested: ${data.documents_ingested} document, ${data.chunks_created} chunks stored in FAISS.`;
      } else {
        statusEl.textContent = "Upload failed: " + (data.detail || "Unknown error");
      }
      fileInput.value = "";
    } catch (err) {
      statusEl.textContent = "Upload error: " + err.message;
    }
  });
}

// ==========================================================================
// UTILITIES
// ==========================================================================

function showError(msg) {
  const empty = document.getElementById("answerEmpty");
  if (empty) {
    empty.style.display = "flex";
    const t = empty.querySelector(".empty-text");
    if (t) t.textContent = msg;
  }
  activateTab("answerTab");
}

/** Escape HTML special chars to prevent XSS */
function escHtml(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * Minimal Markdown to HTML converter.
 * Handles: # headings, **bold**, *italic*, `inline code`, - bullet lists, blank lines.
 * Intentionally simple — avoids importing a full library.
 */
function markdownToHtml(md) {
  if (!md) return "";
  const lines = md.split("\n");
  const out = [];
  let inList = false;

  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];

    // Headings
    if (/^### (.+)/.test(line)) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(`<h3>${escHtml(line.replace(/^### /, ""))}</h3>`);
      continue;
    }
    if (/^## (.+)/.test(line)) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(`<h2>${escHtml(line.replace(/^## /, ""))}</h2>`);
      continue;
    }
    if (/^# (.+)/.test(line)) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(`<h1>${escHtml(line.replace(/^# /, ""))}</h1>`);
      continue;
    }

    // Horizontal rule
    if (/^---+$/.test(line.trim())) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push("<hr>");
      continue;
    }

    // Bullet list item
    if (/^[-*] (.+)/.test(line)) {
      if (!inList) { out.push("<ul>"); inList = true; }
      const text = inlineFormat(line.replace(/^[-*] /, ""));
      out.push(`<li>${text}</li>`);
      continue;
    }

    // End list on blank line
    if (line.trim() === "") {
      if (inList) { out.push("</ul>"); inList = false; }
      continue;
    }

    if (inList) { out.push("</ul>"); inList = false; }
    out.push(`<p>${inlineFormat(line)}</p>`);
  }

  if (inList) out.push("</ul>");
  return out.join("\n");
}

function inlineFormat(text) {
  return escHtml(text)
    // Bold: **text**
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    // Italic: *text*
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    // Inline code: `text`
    .replace(/`([^`]+)`/g, "<code>$1</code>");
}
