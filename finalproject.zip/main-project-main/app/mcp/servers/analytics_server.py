"""
Analytics MCP Server
====================
Exposes business analytics and usage metric tools conforming to the
Model Context Protocol (MCP) standard.

This server is registered as 'analytics_mcp' and exposes two tools:
  - Analytics.get_customer_metrics  : ARR, MRR, NPS, churn risk, SLA compliance
  - Analytics.get_customer_history  : Chronological event timeline (QBRs, incidents, upgrades)

Tool name aliases supported:
  - 'Analytics.get_metrics'   -> same as 'Analytics.get_customer_metrics'
  - 'Analytics.get_history'   -> same as 'Analytics.get_customer_history'
  All names resolved case-insensitively.
"""
from typing import Dict, Any, List


# ---------------------------------------------------------------------------
# Mock Analytics Metrics Store
# In production this would be replaced by calls to a real analytics platform.
# ---------------------------------------------------------------------------
ANALYTICS_METRICS: Dict[str, Dict[str, Any]] = {
    "ABC": {
        "customer_id": "ABC",
        "arr": 450_000,
        "monthly_recurring_revenue": 37_500,
        "churn_risk_score": 0.08,          # Low — below 0.15 threshold
        "nps_score": 72,                   # Excellent (promoter zone: > 50)
        "active_users": 1_840,
        "api_calls_last_30d": 32_450_000,
        "error_rate_percentage": 0.012,    # Very low error rate
        "open_tickets_count": 1,
        "average_ticket_resolution_hours": 1.4,
        "sla_compliance_rate": "99.98%",
        "health_status": "Healthy",
    },
    "XYZ": {
        "customer_id": "XYZ",
        "arr": 120_000,
        "monthly_recurring_revenue": 10_000,
        "churn_risk_score": 0.35,          # Moderate — attention required
        "nps_score": 48,                   # Neutral (requires improvement)
        "active_users": 310,
        "api_calls_last_30d": 4_120_000,
        "error_rate_percentage": 0.28,
        "open_tickets_count": 3,
        "average_ticket_resolution_hours": 4.6,
        "sla_compliance_rate": "98.70%",
        "health_status": "At Risk",
    },
}

ANALYTICS_HISTORY: Dict[str, List[Dict[str, Any]]] = {
    "ABC": [
        {
            "date": "2026-08-15",
            "event_type": "Capacity Upgrade",
            "details": "Provisioned additional dedicated telemetry broker partition.",
            "impact": "Throughput increased by 35%",
        },
        {
            "date": "2026-07-28",
            "event_type": "Quarterly Business Review (QBR)",
            "details": "Executive QBR held with VP of Logistics; renewed commitment to multi-year roadmap.",
            "satisfaction": "Very High",
        },
        {
            "date": "2026-06-10",
            "event_type": "Incident Resolved",
            "details": "Sev-3 minor ingestion delay resolved within 22 minutes under Platinum SLA.",
            "ticket_id": "INC-88912",
        },
    ],
    "XYZ": [
        {
            "date": "2026-08-01",
            "event_type": "Rate Limit Breach Warning",
            "details": "Spike in product catalog queries during flash sale triggered automated 429 warning.",
            "ticket_id": "INC-90114",
        },
        {
            "date": "2026-05-18",
            "event_type": "Annual Renewal Negotiation",
            "details": "Account requested pricing quote for next tier expansion.",
            "status": "Pending",
        },
    ],
}


class AnalyticsMCPServer:
    """
    In-process Analytics MCP server.

    Exposes analytics tools without requiring a network connection.
    The MCPClientManager calls `list_tools()` to discover tools and
    `call_tool(name, args)` to invoke them.
    """

    def __init__(self, server_id: str = "analytics_mcp"):
        self.server_id = server_id

    # ------------------------------------------------------------------
    # Tool Discovery
    # ------------------------------------------------------------------

    def list_tools(self) -> List[Dict[str, Any]]:
        """Return the list of available analytics tools with their JSON Schema parameters."""
        return [
            {
                "name": "Analytics.get_customer_metrics",
                "server_id": self.server_id,
                "description": (
                    "Fetch real-time customer health metrics: ARR, MRR, NPS score, churn risk, "
                    "active users, API call volume, error rate, and SLA compliance percentage."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "customer_id": {
                            "type": "string",
                            "description": "Unique customer identifier, e.g. 'ABC'",
                        }
                    },
                    "required": ["customer_id"],
                },
            },
            {
                "name": "Analytics.get_customer_history",
                "server_id": self.server_id,
                "description": (
                    "Retrieve a chronological event timeline for a customer including "
                    "capacity upgrades, quarterly business reviews, and incident resolutions."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "customer_id": {
                            "type": "string",
                            "description": "Unique customer identifier",
                        },
                        "months": {
                            "type": "integer",
                            "description": "Number of past months of history to return (default: 3)",
                            "default": 3,
                        },
                    },
                    "required": ["customer_id"],
                },
            },
        ]

    # ------------------------------------------------------------------
    # Tool Execution
    # ------------------------------------------------------------------

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the specified analytics tool with the given arguments.

        Supports the following name aliases (all case-insensitive):
          - Analytics.get_customer_metrics | Analytics.get_metrics
          - Analytics.get_customer_history | Analytics.get_history
        """
        # Normalize: strip 'analytics.' prefix and lowercase
        normalized = tool_name.lower().replace("analytics.", "").strip()

        # Both 'get_customer_metrics' and 'get_metrics' map to the same handler
        if normalized in ("get_customer_metrics", "get_metrics"):
            return self._get_customer_metrics(arguments)

        # Both 'get_customer_history' and 'get_history' map to the same handler
        elif normalized in ("get_customer_history", "get_history"):
            return self._get_customer_history(arguments)

        else:
            raise NotImplementedError(
                f"Tool '{tool_name}' is not implemented by the Analytics MCP server. "
                f"Available: Analytics.get_customer_metrics, Analytics.get_customer_history"
            )

    # ------------------------------------------------------------------
    # Internal Tool Handlers
    # ------------------------------------------------------------------

    def _get_customer_metrics(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Retrieve health metrics for a customer."""
        customer_id = arguments.get("customer_id", "").strip().upper()
        if not customer_id:
            raise ValueError("Missing required argument: 'customer_id'")

        metrics = ANALYTICS_METRICS.get(customer_id)
        if not metrics:
            return {
                "found": False,
                "customer_id": customer_id,
                "message": f"No analytics metrics found for customer '{customer_id}'.",
            }

        return {"found": True, "metrics": metrics}

    def _get_customer_history(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Retrieve the event history timeline for a customer."""
        customer_id = arguments.get("customer_id", "").strip().upper()
        months = int(arguments.get("months", 3))

        if not customer_id:
            raise ValueError("Missing required argument: 'customer_id'")

        history = ANALYTICS_HISTORY.get(customer_id, [])
        return {
            "customer_id": customer_id,
            "months_requested": months,
            "event_count": len(history),
            "timeline": history,
        }


# Global singleton — imported by the MCPClientManager
analytics_server_instance = AnalyticsMCPServer()
