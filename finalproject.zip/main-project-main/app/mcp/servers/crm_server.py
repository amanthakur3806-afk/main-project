"""
CRM MCP Server
==============
Exposes customer relationship management (CRM) tools conforming to the
Model Context Protocol (MCP) standard.

This server is registered as 'crm_mcp' and exposes three tools:
  - CRM.get_customer      : Look up a customer by their ID
  - CRM.search_customer   : Search customers by name or keyword
  - CRM.update_notes      : Append a note to a customer's CRM record

Design note: Tool names are resolved case-insensitively and prefix-tolerantly,
so callers may use 'CRM.get_customer', 'crm.get_customer', or simply 'get_customer'.
"""
import datetime
from typing import Dict, Any, List


# ---------------------------------------------------------------------------
# Mock CRM Database
# In production this would be replaced by a real CRM API call or database query.
# ---------------------------------------------------------------------------
CRM_DATABASE: Dict[str, Dict[str, Any]] = {
    "ABC": {
        "customer_id": "ABC",
        "company_name": "ABC Global Logistics & Supply Inc.",
        "tier": "Enterprise Tier 1",
        "industry": "Logistics & Supply Chain",
        "status": "Active",
        "account_executive": "Sarah Jenkins",
        "technical_contact": "Dr. Marcus Vance (marcus.vance@abc-logistics.example.com)",
        "contract_value": "$450,000 / year",
        "contract_start": "2024-01-15",
        "contract_renewal": "2027-01-15",
        "sla_tier": "Platinum Mission-Critical",
        "sla_response_time": "< 15 minutes for Sev-1 incidents",
        "notes": [
            "Completed global telemetry migration in Q3 2024.",
            "Quarterly billing schedule active.",
            "Seasonal burst allowance auto-scales to 120% of base capacity.",
        ],
    },
    "XYZ": {
        "customer_id": "XYZ",
        "company_name": "XYZ Retail Innovations Ltd.",
        "tier": "Growth Tier 2",
        "industry": "E-Commerce",
        "status": "Active",
        "account_executive": "David Kim",
        "technical_contact": "Elena Rostova (elena.rostova@xyzretail.example.com)",
        "contract_value": "$120,000 / year",
        "contract_start": "2024-06-01",
        "contract_renewal": "2025-06-01",
        "sla_tier": "Gold Standard",
        "sla_response_time": "< 4 hours for Sev-1 incidents",
        "notes": [
            "Requested rate limit review for upcoming flash sale.",
        ],
    },
}


class CRMMCPServer:
    """
    In-process CRM MCP server.

    Exposes CRM tools without requiring a network connection.
    Designed so the MCPClientManager can call `list_tools()` to discover
    available tools and `call_tool(name, args)` to invoke them.
    """

    def __init__(self, server_id: str = "crm_mcp"):
        self.server_id = server_id

    # ------------------------------------------------------------------
    # Tool Discovery
    # ------------------------------------------------------------------

    def list_tools(self) -> List[Dict[str, Any]]:
        """Return the list of available tools with their JSON Schema parameters."""
        return [
            {
                "name": "CRM.get_customer",
                "server_id": self.server_id,
                "description": (
                    "Retrieve a comprehensive CRM profile for a customer by their unique ID. "
                    "Returns tier, SLA, stakeholders, contract value, and operational notes."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "customer_id": {
                            "type": "string",
                            "description": "Unique customer identifier, e.g. 'ABC' or 'XYZ'",
                        }
                    },
                    "required": ["customer_id"],
                },
            },
            {
                "name": "CRM.search_customer",
                "server_id": self.server_id,
                "description": (
                    "Search the CRM directory by company name, industry, or customer ID keyword. "
                    "Returns a list of matching customer records."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search term to match against company name, industry, or customer ID",
                        }
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "CRM.update_notes",
                "server_id": self.server_id,
                "description": (
                    "Append an operational note to a customer's CRM record. "
                    "Notes are timestamped automatically."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "customer_id": {
                            "type": "string",
                            "description": "Unique customer ID",
                        },
                        "note": {
                            "type": "string",
                            "description": "Note content to append to the customer record",
                        },
                    },
                    "required": ["customer_id", "note"],
                },
            },
        ]

    # ------------------------------------------------------------------
    # Tool Execution
    # ------------------------------------------------------------------

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the specified tool with the given arguments.

        Resolves tool names case-insensitively and strips common prefixes
        (e.g. 'CRM.', 'crm.') so callers have flexibility in how they name tools.
        """
        # Normalize: strip prefix and lowercase
        normalized = tool_name.lower().replace("crm.", "").strip()

        if normalized == "get_customer":
            return self._get_customer(arguments)

        elif normalized == "search_customer":
            return self._search_customer(arguments)

        elif normalized == "update_notes":
            return self._update_notes(arguments)

        else:
            raise NotImplementedError(
                f"Tool '{tool_name}' is not implemented by the CRM MCP server. "
                f"Available tools: CRM.get_customer, CRM.search_customer, CRM.update_notes"
            )

    # ------------------------------------------------------------------
    # Internal Tool Handlers
    # ------------------------------------------------------------------

    def _get_customer(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Look up a customer by ID."""
        customer_id = arguments.get("customer_id", "").strip().upper()
        if not customer_id:
            raise ValueError("Missing required argument: 'customer_id'")

        customer = CRM_DATABASE.get(customer_id)
        if not customer:
            return {
                "found": False,
                "customer_id": customer_id,
                "message": f"Customer '{customer_id}' was not found in the CRM database.",
            }

        return {"found": True, "customer": customer}

    def _search_customer(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Search customers by name, industry, or ID fragment."""
        query = arguments.get("query", "").lower().strip()
        if not query:
            return {"count": 0, "results": []}

        matches = [
            cust
            for cust in CRM_DATABASE.values()
            if (
                query in cust["company_name"].lower()
                or query in cust["industry"].lower()
                or query in cust["customer_id"].lower()
            )
        ]
        return {"count": len(matches), "results": matches}

    def _update_notes(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Append a timestamped note to a customer record."""
        customer_id = arguments.get("customer_id", "").strip().upper()
        note = arguments.get("note", "").strip()

        if not customer_id:
            raise ValueError("Missing required argument: 'customer_id'")
        if not note:
            raise ValueError("Missing required argument: 'note'")

        if customer_id not in CRM_DATABASE:
            return {
                "success": False,
                "error": f"Customer '{customer_id}' does not exist in CRM.",
            }

        timestamp = datetime.datetime.utcnow().isoformat()
        timestamped_note = f"[{timestamp}] {note}"
        CRM_DATABASE[customer_id]["notes"].append(timestamped_note)

        return {
            "success": True,
            "customer_id": customer_id,
            "notes_count": len(CRM_DATABASE[customer_id]["notes"]),
            "last_note": timestamped_note,
        }


# Global singleton — imported by the MCPClientManager
crm_server_instance = CRMMCPServer()
