"""
FAISS Vector Store
==================
Stores document chunk embeddings and performs fast cosine-similarity search.

Architecture:
    FAISS Vector ID -> metadata_map[id] -> chunk text + document + KB metadata
    This allows the agent to trace every retrieved chunk back to its source file.

Technical details:
    - Index type  : IndexFlatIP (inner product on L2-normalised vectors = cosine similarity)
    - Embedding   : 384-dimensional float32 vectors
    - Persistence : index saved to disk as knowledge_index.faiss,
                    metadata saved as vector_metadata.json
    - KB isolation: each chunk carries a kb_id tag; search() filters by it
                    so agent_A's knowledge cannot leak into agent_B's results.

Fallback:
    If the faiss-cpu binary is unavailable (e.g. an unusual OS environment),
    the store transparently falls back to a pure NumPy cosine similarity search
    over an in-memory matrix.  Performance is lower but correctness is identical.
"""
import json
import logging
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional

from app.config import settings

logger = logging.getLogger("vector_store")


# ---------------------------------------------------------------------------
# Try to import FAISS; fall back to NumPy-only mode if unavailable
# ---------------------------------------------------------------------------
try:
    import faiss
    _FAISS_AVAILABLE = True
except ImportError:
    _FAISS_AVAILABLE = False
    logger.warning(
        "faiss-cpu not installed or failed to load. "
        "Falling back to NumPy cosine similarity search (slower, but functionally identical)."
    )


class FAISSVectorStore:
    """
    Manages persistent FAISS (or NumPy) vector indexing, metadata mapping,
    and cosine-similarity search across knowledge base partitions.
    """

    def __init__(self, storage_dir: Optional[Path] = None, dim: int = 384):
        self.storage_dir = storage_dir or settings.VECTOR_STORE_DIR
        self.dim = dim
        self.index_path = self.storage_dir / "knowledge_index.faiss"
        self.metadata_path = self.storage_dir / "vector_metadata.json"

        # Metadata map: vector_id (int) -> chunk metadata dict
        self.metadata_map: Dict[int, Dict[str, Any]] = {}

        # In-memory matrix used when FAISS is unavailable
        self._numpy_vectors: Optional[np.ndarray] = None

        # FAISS index (None when in NumPy fallback mode)
        self._index = None

        if _FAISS_AVAILABLE:
            self._index = faiss.IndexFlatIP(self.dim)

        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def total_vectors(self) -> int:
        """Number of vectors currently indexed."""
        if _FAISS_AVAILABLE and self._index is not None:
            return self._index.ntotal
        if self._numpy_vectors is not None:
            return self._numpy_vectors.shape[0]
        return 0

    def add_vectors(
        self, vectors: np.ndarray, metadata_list: List[Dict[str, Any]]
    ) -> List[int]:
        """
        Add a batch of L2-normalised vectors and their metadata to the index.
        Returns the list of assigned vector IDs.
        """
        if len(vectors) == 0:
            return []

        vectors = vectors.astype(np.float32)
        start_id = self.total_vectors

        if _FAISS_AVAILABLE and self._index is not None:
            self._index.add(vectors)
        else:
            # Append to the NumPy matrix
            if self._numpy_vectors is None:
                self._numpy_vectors = vectors
            else:
                self._numpy_vectors = np.vstack([self._numpy_vectors, vectors])

        assigned_ids = []
        for i, meta in enumerate(metadata_list):
            vid = start_id + i
            self.metadata_map[vid] = meta
            assigned_ids.append(vid)

        self._save()
        return assigned_ids

    def search(
        self,
        query_vector: np.ndarray,
        top_k: int = 4,
        kb_id: Optional[str] = None,
        min_score: float = 0.05,
    ) -> List[Dict[str, Any]]:
        """
        Find the most semantically similar chunks to the query vector.

        Args:
            query_vector: L2-normalised embedding of the user's query.
            top_k:        Maximum number of chunks to return.
            kb_id:        If provided, only return chunks from this knowledge base.
            min_score:    Minimum cosine similarity score (0-1) to include a result.

        Returns:
            List of result dicts, each containing vector_id, score, chunk text, and metadata.
        """
        if self.total_vectors == 0:
            return []

        query_vector = query_vector.reshape(1, -1).astype(np.float32)
        # Search more candidates than needed so we have room to filter by kb_id
        search_k = min(self.total_vectors, max(top_k * 4, 20))

        if _FAISS_AVAILABLE and self._index is not None:
            scores_arr, indices_arr = self._index.search(query_vector, search_k)
            candidates = list(zip(scores_arr[0], indices_arr[0]))
        else:
            # NumPy cosine similarity (inner product on L2-normalised vectors)
            if self._numpy_vectors is None:
                return []
            sims = (self._numpy_vectors @ query_vector.T).flatten()
            top_indices = np.argsort(sims)[::-1][:search_k]
            candidates = [(float(sims[i]), int(i)) for i in top_indices]

        results = []
        for score, vid in candidates:
            vid = int(vid)
            if vid < 0 or vid not in self.metadata_map:
                continue
            if float(score) < min_score:
                continue

            meta = self.metadata_map[vid]
            if kb_id and meta.get("kb_id") != kb_id:
                continue

            results.append(
                {
                    "vector_id": vid,
                    "score": round(float(score), 4),
                    "chunk_id": meta.get("chunk_id"),
                    "document_id": meta.get("document_id"),
                    "kb_id": meta.get("kb_id"),
                    "filename": meta.get("filename"),
                    "chunk_index": meta.get("chunk_index"),
                    "content": meta.get("content"),
                }
            )

            if len(results) >= top_k:
                break

        return results

    def clear(self):
        """Reset the entire index and metadata store."""
        self.metadata_map = {}
        self._numpy_vectors = None
        if _FAISS_AVAILABLE:
            self._index = faiss.IndexFlatIP(self.dim)
        self._save()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _save(self):
        """Persist the index and metadata to disk."""
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        if _FAISS_AVAILABLE and self._index is not None:
            faiss.write_index(self._index, str(self.index_path))
        else:
            # Save NumPy matrix as .npy
            npy_path = self.storage_dir / "knowledge_index.npy"
            if self._numpy_vectors is not None:
                np.save(str(npy_path), self._numpy_vectors)

        with open(self.metadata_path, "w", encoding="utf-8") as f:
            json.dump({str(k): v for k, v in self.metadata_map.items()}, f, indent=2)

    def _load(self):
        """Load existing index and metadata from disk (if available)."""
        # Load metadata
        if self.metadata_path.exists():
            try:
                with open(self.metadata_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.metadata_map = {int(k): v for k, v in data.items()}
            except Exception as e:
                logger.warning(f"Could not load vector metadata: {e}")
                self.metadata_map = {}

        # Load index
        if _FAISS_AVAILABLE and self._index is not None:
            if self.index_path.exists():
                try:
                    self._index = faiss.read_index(str(self.index_path))
                except Exception as e:
                    logger.warning(f"Could not load FAISS index: {e}")
                    self._index = faiss.IndexFlatIP(self.dim)
        else:
            npy_path = self.storage_dir / "knowledge_index.npy"
            if npy_path.exists():
                try:
                    self._numpy_vectors = np.load(str(npy_path))
                except Exception as e:
                    logger.warning(f"Could not load NumPy index: {e}")
                    self._numpy_vectors = None


# Global singleton — shared across the entire application
vector_store = FAISSVectorStore()
